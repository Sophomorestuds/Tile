# sockets
chat app
This is sample chat application using Node JS & socket.io

Users can chat in realtime across various meeting rooms.

Demo: https://bhupendra1011.herokuapp.com/
